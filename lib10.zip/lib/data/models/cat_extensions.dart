import 'cat_model.dart';

extension CatImage on Cat {
  String get imageUrl => url;
}
